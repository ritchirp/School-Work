/**
 * 
 */
package edu.miamioh.ritchirp;

/**
 * @author ritchirp
 *
 */
public class Instructor extends Person {

}
