package project1;

public enum AppointmentType {
	DAILY, MONTHLY, ONETIME
}
