package edu.miamioh.ritchirp;

public class ResaurantFrameViewer {
	
	// Displays a restaurant frame
	public static void main(String[] args) {
		RestaurantFrame frame = new RestaurantFrame();
		
	}

}
