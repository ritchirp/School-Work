package edu.miamioh.ritchirp;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class RestaurantFrame extends JFrame {
	
	private static final int FRAME_WIDTH = 400;
	private static final int FRAME_HEIGHT = 250;
	
	private static final int AREA_ROWS = 20;
	private static final int AREA_COLUMNS = 2;
	
	private static final double TAX_RATE = 0.03;
	private static final double TIP = 5;
	
	private double total;
	
	private RestaurantButton steakButton;
	private RestaurantButton eggsButton;
	private RestaurantButton drinkButton;
	private RestaurantButton friesButton;
	private RestaurantButton burgerButton;
	
	private JLabel oddItemNameLabel;
	private JTextField oddItemNameField;
	private JLabel oddItemPriceLabel;
	private JTextField oddItemPriceField;
	private JButton addOddItemButton;
	
	private JTextArea billArea;
	
	public RestaurantFrame(){
		total = 0;
		billArea = new JTextArea(AREA_ROWS, AREA_COLUMNS);
	}
	
	private void createOddItemEntry(){
		oddItemNameLabel = new JLabel("Name");
		oddItemNameField = new JTextField();
		oddItemPriceLabel = new JLabel("Price");
		oddItemPriceField = new JTextField();
		
		addOddItemButton = new JButton("Add Item");
		ActionListener listener = new AddItemListener();
		addOddItemButton.addActionListener(listener); 
	}
	
	class AddItemListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			RestaurantButton rb; 
			if(e.getSource() instanceof RestaurantButton){
				rb = (RestaurantButton) e.getSource();
				double price = rb.getPrice();
				billArea.append(rb.getName() + "\n");
				billArea.append(price + "");
				total+=price;
			}
			else{
				double price = Double.parseDouble(oddItemPriceField.getText());
				billArea.append(oddItemNameField.getText() + "\n");
				billArea.append(price + "\n");
				total+=price;
			}
				
		}
		
	}
}
