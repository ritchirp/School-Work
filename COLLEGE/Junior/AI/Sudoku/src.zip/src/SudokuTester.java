
public class SudokuTester {

	public static void main(String[] args) {
		SudokuSolver solver = new SudokuSolver();
		printNodeArray(solver.solve("test1.txt"));
		
		

	}
	
	
	static void printNodeArray(Node[][] a) {
		for(int i = 0; i<a.length; i++) {
			for(int j = 0; j<a[i].length; j++) {
				System.out.print(a[i][j].value + " ");
			}
			System.out.println();
		}
	}
	
}
