// Robert Ritchie
// Prints the word "neat" in asteriks

public class Letters{
   public static void main(String[] args){
      final String LETTER_N = "*    *\n**   *\n* *  *\n*   **\n*    *";
      final String LETTER_E = "******\n*     \n***** \n*     \n******";
      final String LETTER_A = "   *   \n  * *  \n ***** \n*     *\n*     *";
      final String LETTER_T = "******\n  *   \n  *   \n  *   \n  *   ";
      
      System.out.println(LETTER_N);
      System.out.println(LETTER_E);
      System.out.println(LETTER_A);
      System.out.println(LETTER_T);
   }
}