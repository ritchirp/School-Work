// Robert Ritchie
// CSE 174
// Prints a text image of a face

public class TextFace{
   public static void main(String[] args){
   System.out.println("^^^^^^^ \n" + "| o o |\n" + "|  >  | \n" +
                      "| \\_/ | \n" + "|_____|" );
   }
}
   