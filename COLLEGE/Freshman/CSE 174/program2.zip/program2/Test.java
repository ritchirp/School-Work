// Robert Ritchie
// CSE 174
// Displays a custom image and message

import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Test{
   public static void main(String[] args) throws Exception{
    URL imageLocation = new URL(
                                "http://images.mentalfloss.com/sites/default"+
                                   "/files/styles/insert_main_wide_image/public/einstein1_7.jpg");
    JOptionPane.showMessageDialog(null, "Einstein thinks this code is too easy.", "Albert Einstein",
                                  JOptionPane.PLAIN_MESSAGE, new ImageIcon(imageLocation));
   }
}