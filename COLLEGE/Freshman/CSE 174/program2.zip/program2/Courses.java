// Robert Ritchie
// CSE 174
// Displays a table of my courses, their instrutor, and their credit hours for
// the 2016 spring semester

public class Courses{
   public static void main(String[] args){
    System.out.println("Course    Instructor   Credits");  
    System.out.println("------------------------------");
    System.out.println("CSE 174   Krumpe       3      ");
    System.out.println("ART 140   Hubbard      1.5    ");
    System.out.println("ART 165   Sliger       1.5    ");
    System.out.println("ART 188H  Casper       3      ");
    System.out.println("GER 202   Gerhards     3      ");
    System.out.println("MTH 252   Dowling      4      ");
   }
}